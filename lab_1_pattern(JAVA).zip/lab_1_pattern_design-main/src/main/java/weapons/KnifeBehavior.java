package weapons;

public class KnifeBehavior implements WeaponBehavior {
    public void useWeapon() {
        System.out.println("реалізація удору ножем");
    }
}
