package weapons;

public class AxeBehavior implements WeaponBehavior {
    public void useWeapon() {
        System.out.println("реалізація удару сокирою");
    }
}
