package weapons;

public interface WeaponBehavior {
    void useWeapon();
}
