package weapons;

public class SwordBehavior implements WeaponBehavior {
    public void useWeapon() {
        System.out.println("реалізація удару мечем");
    }
}
