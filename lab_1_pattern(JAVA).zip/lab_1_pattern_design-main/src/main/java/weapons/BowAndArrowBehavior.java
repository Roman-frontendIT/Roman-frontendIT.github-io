package weapons;

public class BowAndArrowBehavior implements WeaponBehavior {
    public void useWeapon() {
        System.out.println("реалізація пострілу з лука");
    }
}
