import characters.Troll;
import weapons.SwordBehavior;

public class Main {

    public static void main(String[] args) {
        // вибір персонажа троль, зброя за замовчуванням сокира
        Troll troll = new Troll();
        troll.fight();

        //зміна зброї в грі на меч, тепер буде атакувати мечем
        troll.setWeapon(new SwordBehavior());
        troll.fight();
    }
}